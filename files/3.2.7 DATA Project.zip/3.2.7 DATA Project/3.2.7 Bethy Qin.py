'''Project: 3.2.7
   By: Bethy Qin
'''
import os.path
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

#lists for data
years=[]
word=[]
years2=[]
education=[]
# Opens the first excel data file
directory = os.path.dirname(os.path.abspath(__file__)) 
filename = os.path.join(directory, 'key_word.csv')
datafile = open(filename,'r')
# Goes through all the data in the file
for line in datafile:
    year, frequency = line.split(',')
    years += [year]
    word += [frequency]           
datafile.close()
#Opens the second excel data file
filename = os.path.join(directory, 'education_data.csv')
datafile = open(filename,'r')
#this will assign values from the csv data files and recognize that the data are split by comma
for line in datafile:
    year2, students = line.split(',')        
    years2 += [year2]
    education += [students]            
datafile.close()
#this will plot 2 axes on 1 graph
fig, ax = plt.subplots(1,2)

#this will set labels for the x and y axes 
ax[0].set_xlabel('Year')
ax[0].set_ylabel('Number of times "relaxing music" has been searched')

#this sets the x-axis as years
ax[0].set_xticklabels(years)
#this will draw the line and modify its color and width
ax[0].plot(years, word, color = '#a00cff', linewidth=5)
#this will title the graph and define the color of the title
ax[0].set_title('Graph of Number of Times "Relaxing Music" Has Been Searched From 2009 to 2016', color='black')

#this will set labels for the x and y axes 
ax[1].set_xlabel('Year')
ax[1].set_ylabel('Number of People (Thousands)')
plt.sca(ax[1])
#this sets the x-axis as years
ax[1].set_xticklabels(years)
#this will draw the line and modify its color and width
ax[1].plot(years2, education, color = '#aa8cff', linewidth=5)
#this will title the graph and define its color
ax[1].set_title('Graph of Number of People Enter Undergraduate Schools from 2009 to 2016', color='black')

#this will set the background color for the graphs
ax[0].set_axis_bgcolor('#e8eee8')
ax[1].set_axis_bgcolor('#e8eee8')
#shows the graphs
fig.show()